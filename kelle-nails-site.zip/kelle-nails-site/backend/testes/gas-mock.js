// Minimal in-memory Google Apps Script runtime to execute Code.gs unchanged.
const fs = require('fs');
const vm = require('vm');
const crypto = require('crypto');

function createRuntime(codePath, props) {
  const sheets = {};
  function makeSheet(name) {
    const rows = [];
    const sh = {
      name, rows,
      getDataRange: () => ({ getValues: () => rows.length ? rows.map(r => r.slice()) : [[]] }),
      appendRow: (r) => { rows.push(r.map(v => v)); },
      getRange: (r, c, nr = 1, nc = 1) => ({
        setValues: (vals) => { for (let i = 0; i < nr; i++) { rows[r - 1 + i] = rows[r - 1 + i] || []; for (let j = 0; j < nc; j++) rows[r - 1 + i][c - 1 + j] = vals[i][j]; } },
        setValue: (v) => { rows[r - 1] = rows[r - 1] || []; rows[r - 1][c - 1] = v; },
        setNumberFormat: () => {}
      }),
      setFrozenRows: () => {},
      getLastRow: () => rows.length,
      deleteRow: (r) => { rows.splice(r - 1, 1); }
    };
    return sh;
  }
  const ss = {
    getSheetByName: (n) => sheets[n] || null,
    insertSheet: (n) => (sheets[n] = makeSheet(n))
  };
  const files = {};
  const mails = [];
  let locked = false;
  const cache = {};
  const ctx = {
    SpreadsheetApp: { getActiveSpreadsheet: () => ss, flush: () => {} },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => props[k] === undefined ? null : props[k], setProperty: (k, v) => { props[k] = v; } }) },
    LockService: { getScriptLock: () => ({ tryLock: () => { if (locked) return false; locked = true; return true; }, waitLock: () => { locked = true; }, releaseLock: () => { locked = false; } }) },
    CacheService: { getScriptCache: () => ({ get: k => cache[k] || null, put: (k, v) => { cache[k] = v; } }) },
    MailApp: { sendEmail: (to, subj, body) => mails.push({ to, subj, body }) },
    DriveApp: {
      Access: { ANYONE_WITH_LINK: 'A' }, Permission: { VIEW: 'V' },
      getFolderById: (id) => ({ createFile: mkFile }),
      createFolder: () => ({ getId: () => 'folder1', createFile: mkFile }),
      getFileById: (id) => ({ setTrashed: (v) => { if (files[id]) files[id].trashed = v; } })
    },
    Utilities: {
      formatDate: (d, tz, fmt) => {
        const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(d).map(x => [x.type, x.value]));
        return fmt.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute);
      },
      getUuid: () => crypto.randomUUID(),
      base64Decode: (s) => Buffer.from(s, 'base64'),
      newBlob: (bytes, mime, name) => ({ bytes, mime, name })
    },
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (s) => ({ s, setMimeType() { return this; }, getContent() { return this.s; } }) },
    console, Date, Math, JSON
  };
  function mkFile(blob) {
    const id = 'file' + Object.keys(files).length;
    files[id] = { blob, trashed: false, shared: false };
    return { getId: () => id, setSharing: () => { files[id].shared = true; } };
  }
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(codePath, 'utf8'), ctx, { filename: 'Code.gs' });
  ctx.setup();
  return {
    ctx, sheets, files, mails, props,
    get: (params) => JSON.parse(ctx.doGet({ parameter: params }).getContent()),
    post: (body) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(body) } }).getContent())
  };
}
module.exports = { createRuntime };
