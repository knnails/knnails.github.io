const assert = require('assert');
const { createRuntime } = require('./gas-mock');
const CODE = require('path').join(__dirname, '..', 'Code.gs');
let pass = 0;
function test(name, fn) { try { fn(); pass++; console.log('✓', name); } catch (e) { console.log('✗', name, '\n   ', e.message); process.exitCode = 1; } }

const rt = createRuntime(CODE, { ADMIN_PASSWORD: 'segredo123', WHATSAPP_NUMBER: '447700900123', NOTIFY_EMAIL: 'kelle@example.com' });
const A = (b) => rt.post(Object.assign({ password: 'segredo123' }, b));

test('sem horários definidos → nenhuma data disponível (nada inventado)', () => {
  const r = rt.get({ action: 'slots' });
  assert.strictEqual(r.ok, true); assert.deepStrictEqual(r.days, {});
});
test('admin: palavra-passe errada é recusada', () => {
  assert.strictEqual(rt.post({ action: 'adminData', password: 'x' }).error, 'unauthorized');
});
test('admin: horário inválido é recusado', () => {
  assert.strictEqual(A({ action: 'adminSaveSchedule', schedule: { 2: '25:00' } }).error, 'invalid_time');
});
test('admin define horários (ter–sáb)', () => {
  const r = A({ action: 'adminSaveSchedule', schedule: { 2: '10:00, 13:00', 3: '10:00,13:00', 4: '10:00', 5: '10:00', 6: '9:30' } });
  assert.strictEqual(r.ok, true);
  const d = A({ action: 'adminData' });
  assert.strictEqual(d.schedule[6].times, '09:30');
});
let slots, date, time;
test('disponibilidade reflete os horários e só mostra dias futuros', () => {
  slots = rt.get({ action: 'slots' }).days;
  const keys = Object.keys(slots).sort();
  assert.ok(keys.length > 20);
  const today = rt.ctx.Utilities.formatDate(new Date(), 'Europe/London', 'yyyy-MM-dd');
  assert.ok(keys[0] >= today);
  keys.forEach(k => { const wd = new Date(k + 'T12:00:00Z').getUTCDay(); assert.ok(wd >= 2 && wd <= 6, k); });
  date = keys[1]; time = slots[date][0];
});
const base = () => ({ action: 'book', service: 'fibra', date, time, name: 'Ana Teste', whatsapp: '+44 7700 900111', acceptTerms: true, lang: 'pt' });
let booking;
test('pedido válido é registado e devolve link de WhatsApp preenchido', () => {
  booking = rt.post(base());
  assert.strictEqual(booking.ok, true, JSON.stringify(booking));
  assert.match(booking.code, /^KN-[A-Z2-9]{6}$/);
  assert.ok(booking.waUrl.startsWith('https://wa.me/447700900123?text='));
  const txt = decodeURIComponent(booking.waUrl.split('text=')[1]);
  ['Ana Teste', '+447700900111', 'Alongamento em fibra de vidro', time, booking.code].forEach(s => assert.ok(txt.includes(s), s));
  assert.ok(txt.includes(date.split('-').reverse().join('/')));
  assert.strictEqual(rt.mails.length, 1);
});
test('horário reservado desaparece da disponibilidade', () => {
  assert.ok(!(rt.get({ action: 'slots' }).days[date] || []).includes(time));
});
test('reserva duplicada no mesmo horário é recusada', () => {
  assert.strictEqual(rt.post(Object.assign(base(), { name: 'Outra', whatsapp: '07700900222' })).error, 'slot_unavailable');
});
test('validações: serviço inexistente, nome, telefone, termos, horário fora da agenda', () => {
  assert.strictEqual(rt.post(Object.assign(base(), { service: 'nailart' })).error, 'invalid_service');
  assert.strictEqual(rt.post(Object.assign(base(), { name: 'A' })).error, 'invalid_name');
  assert.strictEqual(rt.post(Object.assign(base(), { whatsapp: '123' })).error, 'invalid_phone');
  assert.strictEqual(rt.post(Object.assign(base(), { acceptTerms: false })).error, 'terms_required');
  assert.strictEqual(rt.post(Object.assign(base(), { time: '03:00' })).error, 'slot_unavailable');
  assert.strictEqual(rt.post(Object.assign(base(), { date: '2020-01-07' })).error, 'slot_unavailable');
});
test('novos serviços confirmados aceites (francesinha e cutilagem) e Nail Art recusada', () => {
  const s = rt.get({ action: 'slots' }).days; const ks = Object.keys(s).sort();
  const svcs = ['francesinha', 'cut_maos', 'cut_pes', 'cut_maos_pes'];
  svcs.forEach((sv, i) => {
    const d = ks[12 + i]; const r = rt.post(Object.assign(base(), { service: sv, date: d, time: s[d][0], name: 'Teste ' + sv, whatsapp: '44770090' + (1000 + i) }));
    assert.strictEqual(r.ok, true, sv + JSON.stringify(r));
  });
  const txt = decodeURIComponent(rt.post(Object.assign(base(), { service: 'cut_maos_pes', date: ks[16], time: s[ks[16]][0], name: 'Gabi', whatsapp: '447700901999' })).waUrl);
  assert.ok(txt.includes('Cutilagem — mãos e pés'));
  assert.strictEqual(rt.post(Object.assign(base(), { service: 'nail_art' })).error, 'invalid_service');
});
test('armadilha anti-spam', () => {
  assert.strictEqual(rt.post(Object.assign(base(), { website: 'http://spam' })).ok, false);
});
test('dia bloqueado deixa de aparecer', () => {
  const d2 = Object.keys(slots).sort()[3];
  A({ action: 'adminBlock', date: d2, reason: 'folga' });
  assert.ok(!rt.get({ action: 'slots' }).days[d2]);
  A({ action: 'adminUnblock', date: d2 });
  assert.ok(rt.get({ action: 'slots' }).days[d2]);
});
test('sem WHATSAPP_NUMBER → devolve texto para copiar, sem link', () => {
  const rt2 = createRuntime(CODE, { ADMIN_PASSWORD: 'p' });
  rt2.post({ action: 'adminSaveSchedule', password: 'p', schedule: { 0: '10:00', 1: '10:00', 2: '10:00', 3: '10:00', 4: '10:00', 5: '10:00', 6: '10:00' } });
  const s = rt2.get({ action: 'slots' }).days; const d = Object.keys(s).sort()[1];
  const r = rt2.post({ action: 'book', service: 'shellac', date: d, time: '10:00', name: 'Bia', whatsapp: '447700900333', acceptTerms: true, lang: 'en' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.waUrl, null);
  assert.ok(r.text.includes('Shellac application') && r.text.includes('Request code'));
});
test('cancelar liberta o horário; reativar só se continuar livre', () => {
  const d = A({ action: 'adminData' }); const b = d.bookings.find(x => x.code === booking.code);
  A({ action: 'adminUpdateBooking', id: b.id, status: 'cancelada' });
  assert.ok(rt.get({ action: 'slots' }).days[date].includes(time));
  const other = rt.post(Object.assign(base(), { name: 'Carla', whatsapp: '447700900444' }));
  assert.strictEqual(other.ok, true);
  assert.strictEqual(A({ action: 'adminUpdateBooking', id: b.id, status: 'pendente' }).error, 'slot_unavailable');
});
let carla;
test('avaliação só depois de concluída, uma por atendimento, com WhatsApp correto', () => {
  const d = A({ action: 'adminData' }); carla = d.bookings.find(x => x.name === 'Carla');
  const rv = { action: 'review', code: carla.code, whatsapp: '+44 7700 900444', rating: 5, text: 'Adorei o resultado!', allowPublish: true };
  assert.strictEqual(rt.post(rv).error, 'not_completed');
  A({ action: 'adminUpdateBooking', id: carla.id, status: 'concluida' });
  assert.strictEqual(rt.post(Object.assign({}, rv, { whatsapp: '447700900999' })).error, 'not_found');
  assert.strictEqual(rt.post(rv).ok, true);
  assert.strictEqual(rt.post(rv).error, 'already_reviewed');
});
test('avaliação só aparece no site depois de aprovada, e sem nome', () => {
  assert.strictEqual(rt.get({ action: 'public' }).reviews.length, 0);
  const r = A({ action: 'adminData' }).reviews[0];
  A({ action: 'adminReview', id: r.id, status: 'aprovada' });
  const pub = rt.get({ action: 'public' }).reviews;
  assert.strictEqual(pub.length, 1);
  assert.ok(!JSON.stringify(pub).includes('Carla') && !JSON.stringify(pub).includes('900444'));
});
test('avaliação sem autorização de publicação nunca pode ser publicada', () => {
  const d = A({ action: 'adminData' });
  const b = d.bookings.find(x => x.code === booking.code); // cancelada → usar novo atendimento
  const s = rt.get({ action: 'slots' }).days; const dd = Object.keys(s).sort()[5];
  const nb = rt.post(Object.assign(base(), { date: dd, time: s[dd][0], name: 'Dora', whatsapp: '447700900555' }));
  const id = A({ action: 'adminData' }).bookings.find(x => x.code === nb.code).id;
  A({ action: 'adminUpdateBooking', id, status: 'concluida' });
  rt.post({ action: 'review', code: nb.code, whatsapp: '447700900555', rating: 4, text: 'Bom', allowPublish: false });
  const rv = A({ action: 'adminData' }).reviews.find(x => x.code === nb.code);
  assert.strictEqual(A({ action: 'adminReview', id: rv.id, status: 'aprovada' }).error, 'no_permission');
});
test('fotografia: recusada sem autorização; com autorização fica pendente até aprovação', () => {
  const img = Buffer.from('fake').toString('base64');
  assert.strictEqual(A({ action: 'adminUploadPhoto', code: carla.code, mime: 'image/jpeg', data: img }).error, 'no_consent');
  assert.strictEqual(rt.post({ action: 'consent', code: carla.code, whatsapp: '447700900444', consent: true }).ok, true);
  assert.strictEqual(A({ action: 'adminUploadPhoto', code: carla.code, mime: 'image/jpeg', data: img, caption: 'Fibra nude' }).ok, true);
  assert.strictEqual(rt.get({ action: 'public' }).photos.length, 0);
  const p = A({ action: 'adminData' }).photos[0];
  A({ action: 'adminPhoto', id: p.id, status: 'aprovada' });
  assert.strictEqual(rt.get({ action: 'public' }).photos.length, 1);
});
test('retirar autorização remove a fotografia do site imediatamente', () => {
  rt.post({ action: 'consent', code: carla.code, whatsapp: '447700900444', consent: false });
  assert.strictEqual(rt.get({ action: 'public' }).photos.length, 0);
  assert.strictEqual(Object.values(rt.files)[0].trashed, true);
});
test('indicação é registada e a recompensa é marcada pela admin', () => {
  const s = rt.get({ action: 'slots' }).days; const dd = Object.keys(s).sort()[6];
  const nb = rt.post(Object.assign(base(), { date: dd, time: s[dd][0], name: 'Eva', whatsapp: '447700900666', referral: 'Ana Teste' }));
  assert.ok(decodeURIComponent(nb.waUrl).includes('Indicada por: Ana Teste'));
  const b = A({ action: 'adminData' }).bookings.find(x => x.code === nb.code);
  assert.strictEqual(b.referral, 'Ana Teste');
  A({ action: 'adminUpdateBooking', id: b.id, status: 'concluida', paid: true, reward: true });
  const b2 = A({ action: 'adminData' }).bookings.find(x => x.code === nb.code);
  assert.ok(b2.paid && b2.reward);
});
test('dados públicos nunca expõem nomes ou telefones', () => {
  const s = JSON.stringify(rt.get({ action: 'public' })) + JSON.stringify(rt.get({ action: 'slots' }));
  ['Ana', 'Carla', 'Eva', '7700'].forEach(x => assert.ok(!s.includes(x), x));
});
test('máx. 3 pedidos ativos por número', () => {
  const s = rt.get({ action: 'slots' }).days; const ks = Object.keys(s).sort().slice(8);
  const res = ks.slice(0, 4).map(d => rt.post(Object.assign(base(), { date: d, time: s[d][0], name: 'Fê', whatsapp: '447700900777' })).ok || false);
  assert.deepStrictEqual(res, [true, true, true, false]);
});
test('bloqueio após 10 tentativas erradas de palavra-passe', () => {
  for (let i = 0; i < 12; i++) rt.post({ action: 'adminData', password: 'errada' });
  assert.strictEqual(A({ action: 'adminData' }).error, 'locked');
});
console.log(`\n${pass} testes passaram`);
